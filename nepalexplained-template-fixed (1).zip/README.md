# NepalExplained Template
Static starter template.